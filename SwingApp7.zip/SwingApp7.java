// This code is based on Chatgbt created by the company called OpenAi in the year March 2023
package com.mycompany.swingapp7;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import java.util.regex.Pattern;

public class SwingApp7 {
static class User {
    String firstName;
    String lastName;
    String username;
   String password;

        User(String firstName, String lastName, String username, String password) {
            
            this.firstName = firstName;
            
            this.lastName = lastName;
            
            this.username = username;
            
            this.password = password;
        }
    }

    static HashMap<String, User> userDatabase = new HashMap<>();

    public static void main(String[] args) {
        
        SwingUtilities.invokeLater(() -> showIntroductionScreen());
    }
    class Login {
        
    private static HashMap<String, SwingApp7.User> userDatabase = new HashMap<>();

    
    public static boolean checkUsername(String username) {
        
        return username.length() <= 15 && username.contains("_");
    }

    
    public static boolean checkPasswordComplexity(String password) {
        
        return password.length() >= 8 &&
                
               password.matches(".*[A-Z].*") && 
                
               password.matches(".*[0-9].*") &&
                
               password.matches(".*[!@#$%^&*(),.?\":{}|<>].*"); 
    }

    
    public static boolean checkCellphoneNumber(String phoneNumber) {
        String regex = "^[0-9]{10}$"; 
        return Pattern.matches(regex, phoneNumber);
    }

  
    public static String registerUser(String firstName, String lastName, String username, String password) {
        if (firstName.isEmpty() || lastName.isEmpty()) {
            return "First and last names cannot be empty.";
        } else if (!checkUsername(username)) {
            return "Username must include '_' and be ≤ 15 characters.";
        } else if (!checkPasswordComplexity(password)) {
            return "Password must be ≥ 8 chars, include uppercase, number, symbol.";
        } else {
            SwingApp7.User newUser = new SwingApp7.User(firstName, lastName, username, password);
            userDatabase.put(username, newUser);
            return "User registered successfully!";
        }
    }

  
    public static String loginUser(String username, String password) {
        if (userDatabase.containsKey(username)) {
            SwingApp7.User user = userDatabase.get(username);
            if (user.password.equals(password)) {
                return "Login successful! Welcome " + user.firstName + " " + user.lastName + ".";
            } else {
                return "Username or password incorrect.";
            }
        } else {
            return "Username does not exist.";
        }
    }

    
    public static String returnLoginStatus(String status) {
        return status;
    }
}

   
    public static void showIntroductionScreen() {
        JFrame frame = new JFrame("ChatGuru - Welcome");
        
        frame.setSize(500, 300);
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        frame.setLocationRelativeTo(null);
        
        JLabel appTitle = new JLabel(" ChatGuru ", SwingConstants.CENTER);
        
        appTitle.setFont(new Font("Arial", Font.BOLD, 32));
        
        appTitle.setForeground(Color.WHITE);
        
        JLabel welcomeText = new JLabel("Welcome To ChatGuru, Remember To Always Smile ", SwingConstants.CENTER);
        welcomeText.setFont(new Font("Arial", Font.PLAIN, 16));
        
        welcomeText.setForeground(Color.WHITE);
        
        welcomeText.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        JButton continueButton = new JButton("Continue");
        
        continueButton.setFont(new Font("Arial", Font.BOLD, 16));
        
        JPanel panel = new JPanel(new BorderLayout());
        
        panel.setBackground(Color.ORANGE);
        
        panel.add(appTitle, BorderLayout.NORTH);
        
        panel.add(welcomeText, BorderLayout.CENTER);
        
        panel.add(continueButton, BorderLayout.SOUTH);
        
        frame.add(panel);
        
        frame.setVisible(true);
        
        continueButton.addActionListener(e -> {
            frame.dispose();
            showRegistrationForm();
        });
    }

    
    public static void showRegistrationForm() {
        JFrame frame = new JFrame("Register Account");
        frame.setSize(500, 450);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        JLabel title = new JLabel("Register Account", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        title.setForeground(Color.WHITE);

        JLabel firstNameLabel = new JLabel("First Name:");
        JTextField firstNameField = new JTextField(20);
        firstNameField.setBackground(Color.WHITE);

        JLabel lastNameLabel = new JLabel("Last Name:");
        JTextField lastNameField = new JTextField(20);
        lastNameField.setBackground(Color.WHITE);

        JLabel usernameLabel = new JLabel("Username:");
        JTextField usernameField = new JTextField(20);
        usernameField.setBackground(Color.WHITE);

        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField(20);
        passwordField.setBackground(Color.WHITE);

        JButton registerButton = new JButton("Register");
        JLabel feedbackLabel = new JLabel("", SwingConstants.CENTER);
        feedbackLabel.setForeground(Color.WHITE);

        JPanel formPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 40, 10, 40));
        formPanel.setBackground(Color.ORANGE);
        formPanel.add(firstNameLabel);
        formPanel.add(firstNameField);
        formPanel.add(lastNameLabel);
        formPanel.add(lastNameField);
        formPanel.add(usernameLabel);
        formPanel.add(usernameField);
        formPanel.add(passwordLabel);
        formPanel.add(passwordField);
        formPanel.add(new JLabel());
        formPanel.add(registerButton);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.ORANGE);
        mainPanel.add(title, BorderLayout.NORTH);
        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(feedbackLabel, BorderLayout.SOUTH);

        frame.add(mainPanel);
        frame.setVisible(true);

        registerButton.addActionListener(e -> {
            String firstName = firstNameField.getText().trim();
            String lastName = lastNameField.getText().trim();
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword());

            
            if (firstName.isEmpty() || lastName.isEmpty()) {
                feedbackLabel.setText("First and last names cannot be empty.");
                feedbackLabel.setForeground(Color.RED);
            } else if (!isValidUsername(username)) {
                feedbackLabel.setText("Username must include '_' and be ≤ 15 characters.");
                feedbackLabel.setForeground(Color.RED);
            } else if (!isValidPassword(password)) {
                feedbackLabel.setText("Password must be ≥ 8 chars, include uppercase, number, symbol.");
                feedbackLabel.setForeground(Color.RED);
            } else {
                userDatabase.put(username, new User(firstName, lastName, username, password));
                feedbackLabel.setText("Registered successfully! Redirecting to login...");
                feedbackLabel.setForeground(Color.BLACK);

                Timer timer = new Timer(2000, ev -> {
                    frame.dispose();
                    showLoginForm();
                });
                timer.setRepeats(false);
                timer.start();
            }
        });
    }

  
    public static void showLoginForm() {
        JFrame frame = new JFrame("Login");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        JLabel title = new JLabel("Login", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setForeground(Color.WHITE);
        title.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));

        JLabel usernameLabel = new JLabel("Username:");
        JTextField usernameField = new JTextField(20);
        usernameField.setBackground(Color.WHITE);

        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField(20);
        passwordField.setBackground(Color.WHITE);

        JButton loginButton = new JButton("Login");
        JLabel feedbackLabel = new JLabel("", SwingConstants.CENTER);
        feedbackLabel.setForeground(Color.WHITE);

        JPanel formPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 40, 10, 40));
        formPanel.setBackground(Color.YELLOW);
        formPanel.add(usernameLabel);
        formPanel.add(usernameField);
        formPanel.add(passwordLabel);
        formPanel.add(passwordField);
        formPanel.add(new JLabel());
        formPanel.add(loginButton);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.ORANGE);
        mainPanel.add(title, BorderLayout.NORTH);
        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(feedbackLabel, BorderLayout.SOUTH);

        frame.add(mainPanel);
        frame.setVisible(true);

        loginButton.addActionListener(e -> {
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword());

            if (userDatabase.containsKey(username)) {
                User user = userDatabase.get(username);
                if (user.password.equals(password)) {
                    feedbackLabel.setText(" Welcome " + user.firstName + ", " + user.lastName + "! It is great to have you back again.");
                    feedbackLabel.setForeground(new Color(0, 128, 0));
                } else {
                    feedbackLabel.setText(" Username or password invalid. Please try entering them again.");
                    
                    feedbackLabel.setForeground(Color.BLACK);
                }
            } else {
                feedbackLabel.setText(" Username or password invalid. Please try entering them again.");
                
                feedbackLabel.setForeground(Color.BLACK);
            }
        });
    }

   
    public static boolean isValidUsername(String username) {
        return username.length() <= 15 && username.contains("_");
    }
   
    public static boolean isValidPassword(String password) {
        return password.length() >= 8 &&
               password.matches(".*[A-Z].*") &&
               password.matches(".*[0-9].*") &&
               password.matches(".*[!@#$%^&*(),.?\":{}|<>].*");
    }
}
