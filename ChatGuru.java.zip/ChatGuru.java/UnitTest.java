package com.chatguru.tests;

import com.chatguru.utils.MessageHandler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class UnitTest {

    private MessageHandler handler;

    @BeforeEach
    public void setUp() {
        handler = new MessageHandler();
    }

    @Test
    public void testCheckMessageId_Valid() {
        assertTrue(handler.checkMessageId("1234567890"));
    }

    @Test
    public void testCheckMessageId_Invalid() {
        assertFalse(handler.checkMessageId("12345abc90"));
        assertFalse(handler.checkMessageId("123456789")); // 9 digits only
        assertFalse(handler.checkMessageId(null));
    }

    @Test
    public vpackage com.chatguru.tests;

import com.chatguru.utils.MessageHandler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

    private void assertTrue(boolean checkMessageId) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertFalse(boolean checkMessageId) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

public class UnitTest {

    private MessageHandler handler;

    @BeforeEach
    public void setUp() {
        handler = new MessageHandler();
    }

    @Test
    public void testCheckMessageId_Valid() {
        assertTrue(handler.checkMessageId("1234567890"));
    }

oid testCheckRecipientCell_Valid() {
        assertEquals(1, handler.checkRecipientCell("+123456789"));
        assertEquals(1, handler.checkRecipientCell("+2782123456"));
}

    @Test
    public void testCheckRecipientCell_Invalid() {
        assertEquals(0, handler.checkRecipientCell("123456789"));
        assertEquals(0, handler.checkRecipientCell("+1234567890123")); // too long
        assertEquals(0, handler.checkRecipientCell(null));
    }

    @Test
    public void testCreateMessageHash() {
        String id = "1234567890";
        int messageNumber = 5;
        String message = "hello";
        String expectedHash = "12:5:HO"; // first char 'h'->H, last char 'o'->O
        assertEquals(expectedHash, handler.createMessageHash(id, messageNumber, message));
    }

    @Test
    public void testCreateMessageHash_EmptyMessage() {
        assertEquals("", handler.createMessageHash("1234567890", 1, ""));
    }

    @Test
    public void testSendMessages_IncrementsCounter() {
        int before = handler.returnTotalMessages();
        handler.sendMessages("Test message details");
        int after = handler.returnTotalMessages();
        assertEquals(before + 1, after);
    }

    @Test
    public void testPrintMessage() {
        String id = "1234567890";
        String hash = "12:1:HA";
        String recipient = "+2782123456";
        String message = "Hello again";
        String expected = "Message ID: 1234567890\n" +
                          "Message Hash: 12:1:HA\n" +
                          "Recipient: +2782123456\n" +
                          "Message: Hello again";
        assertEquals(expected, handler.printMessage(id, hash, recipient, message));
    }

    private void assertEquals(String expected, String printMessage) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertTrue(boolean checkMessageId) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertFalse(boolean checkMessageId) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertEquals(int i, int checkRecipientCell) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}


