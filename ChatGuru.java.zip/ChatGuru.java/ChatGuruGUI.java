package com.chatguru.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

public class ChatGuruGUI extends JFrame {
    private JTextArea chatArea;
    private JTextField inputField;
    private JButton sendButton;
    private String username;
    private int messageNumber = 1;
    private int totalMessagesToSend;
    private int sentCount = 0;
    private List<String> messages = new ArrayList<>();

    public ChatGuruGUI(String username) {
        this.username = username;

        
        String input = JOptionPane.showInputDialog(this, "How many messages would you like to send?");
        if (input == null || input.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "You must enter a number.", "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(0);
        }

        try {
            totalMessagesToSend = Integer.parseInt(input.trim());
            if (totalMessagesToSend <= 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid number entered.", "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(0);
        }

        setTitle("ChatGuru - Chat Window");
        setSize(500, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        chatArea = new JTextArea();
        chatArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(chatArea);

        inputField = new JTextField();
        sendButton = new JButton("Send");

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(inputField, BorderLayout.CENTER);
        bottomPanel.add(sendButton, BorderLayout.EAST);

        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        
        sendButton.addActionListener(e -> sendMessage());
        inputField.addActionListener(e -> sendMessage());

        setVisible(true);
    }

    ChatGuruGUI(String username) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void sendMessage() {
        if (sentCount >= totalMessagesToSend) {
            JOptionPane.showMessageDialog(this, "You've already sent all allowed messages.");
            return;
        }

        String text = inputField.getText().trim();

        if (text.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Message cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        
        String recipient = JOptionPane.showInputDialog(this, "Enter recipient number (e.g. +2712345678):");
        if (recipient == null || recipient.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Recipient number is required.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String messageId = String.format("%010d", new Random().nextInt(1_000_000_000));
        String hash = messageId.substring(0, 2) + ":" + "M" + messageNumber;

        String fullMessage = String.format("To: %s\nMsg#: %d\nID: %s\nHash: %s\nMsg: %s\n------------------------",
                recipient, messageNumber, messageId, hash, text);

        chatArea.append("You: " + text + "\n");
        messages.add(fullMessage);

        
        String fullMessageInfo = "Message Sent Successfully!\n\n" +
                " Message ID: " + messageId + "\n" +
                " Message Hash: " + hash + "\n" +
                " Recipient: " + recipient + "\n" +
                " Message: " + text;
        JOptionPane.showMessageDialog(this, fullMessageInfo, "Message Details", JOptionPane.INFORMATION_MESSAGE);

        inputField.setText("");
        messageNumber++;
        sentCount++;

      
        if (sentCount == totalMessagesToSend) {
            JOptionPane.showMessageDialog(this, "You have sent " + sentCount + " messages successfully!", "Summary", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
