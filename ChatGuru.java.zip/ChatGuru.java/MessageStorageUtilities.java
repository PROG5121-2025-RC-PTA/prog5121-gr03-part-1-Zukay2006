package com.chatguru.gui;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class MessageStorageUtilities {

    private static final String FILE_NAME = "messages.txt";

    
    public static void saveMessage(String messageLine) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME, true))) {
            writer.write(messageLine);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    
    public static List<String> readMessages() {
        List<String> messages = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                messages.add(line);
            }
        } catch (FileNotFoundException e) {
            
        } catch (IOException e) {
            e.printStackTrace();
        }
        return messages;
    }

    
    public static void clearMessages() {
        try (PrintWriter writer = new PrintWriter(FILE_NAME)) {
            writer.print("");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
