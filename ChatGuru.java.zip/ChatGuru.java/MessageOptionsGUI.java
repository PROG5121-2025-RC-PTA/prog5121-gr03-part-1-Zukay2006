package com.chatguru.gui;

import javax.swing.*;
import java.awt.*;

public class MessageOptionsGUI extends JFrame {
    private final String username;

    public MessageOptionsGUI(String username) {
        super("ChatGuru - Options");
        this.username = username;

        setLayout(new GridLayout(3, 1, 10, 10));
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JButton btnSendMessages = new JButton("Send Messages");
        JButton btnShowRecent = new JButton("Show Recent Messages (Coming Soon)");
        JButton btnQuit = new JButton("Quit");

        add(btnSendMessages);
        add(btnShowRecent);
        add(btnQuit);

        btnSendMessages.addActionListener(e -> {
            new ChatGuruGUI(username);
            this.dispose();
        });

        btnShowRecent.addActionListener(e ->
                JOptionPane.showMessageDialog(this, "Feature coming soon!")
        );

        btnQuit.addActionListener(e -> System.exit(0));
    }
}
