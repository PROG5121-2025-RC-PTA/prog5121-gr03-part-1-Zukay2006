package com.chatguru.client;

import java.io.*;
import java.net.Socket;

public class ChatClient {

    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;
    private MessageListener listener;
    private Thread listenThread;

    public interface MessageListener {
        void onMessageReceived(String message);
        void onConnectionClosed();
    }

    
    public ChatClient(String serverAddress, int port, MessageListener listener) throws IOException {
        this.listener = listener;
        socket = new Socket(serverAddress, port);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        out = new PrintWriter(socket.getOutputStream(), true);
        startListening();
    }

    
    private void startListening() {
        listenThread = new Thread(() -> {
            try {
                String line;
                while ((line = in.readLine()) != null) {
                    if (listener != null) {
                        listener.onMessageReceived(line);
                    }
                }
            } catch (IOException e) {
                
            } finally {
                close();
                if (listener != null) {
                    listener.onConnectionClosed();
                }
            }
        });
        listenThread.start();
    }

  
    public void sendMessage(String message) {
        if (out != null) {
            out.println(message);
        }
    }

    
    public void close() {
        try {
            if (out != null) out.close();
            if (in != null) in.close();
            if (socket != null && !socket.isClosed()) socket.close();
        } catch (IOException e) {
           
        }
    }
}
