package com.mycompany.tvstreaming;

// Scanner and ArrayList are imported so that we can use them later in the code
import java.util.ArrayList;
import java.util.Scanner;

// Public class to create the main application object
public class TVStreaming {
    public static void main(String[] args) {
        Series app = new Series(); 
        app.runApplication(); // Start the series management application
    }
}

// Series class containing all methods 
class Series {
    private ArrayList<SeriesData> seriesList = new ArrayList<>(); // Store all series
    private Scanner input = new Scanner(System.in); // Scanner is used to get user input

    //used to store data for each series
    static class SeriesData {
        public String id;
        public String name;
        public String ageRestriction;
        public String numberOfEpisodes;

        public SeriesData(String id, String name, String ageRestriction, String numberOfEpisodes) {
            this.id = id;
            this.name = name;
            this.ageRestriction = ageRestriction;
            this.numberOfEpisodes = numberOfEpisodes;
        }

        // Prints the details of a series 
        public void printInfo() {
            System.out.println("Series Info {");
            System.out.println("  ID: " + id);
            System.out.println("  Name: " + name);
            System.out.println("  Age Restriction: " + ageRestriction);
            System.out.println("  Episodes: " + numberOfEpisodes);
            System.out.println("}");
        }
    }

    public void runApplication() {
        System.out.println("Enter (1) to launch menu or any other key to exit:");
        String start = input.nextLine();
        if (!start.equals("1")) {
            System.out.println("Exiting application...");
            return;
        }

        boolean running = true;
        while (running) {
            showMenu(); 
            String choice = input.nextLine();

            // Switch checks the user choice
            switch (choice) {
                case "1": captureSeries(); break;
                case "2": searchSeries(); break;
                case "3": updateExistingSeries(); break;
                case "4": deleteSeries(); break;
                case "5": PrintTheSeries(); break;
                case "6": CloseApplication(); running = false; break;
                default: System.out.println("Invalid option. Try again.");
            }
        }

        input.close(); 
    }

    private void showMenu() {
        System.out.println("1. Capture New Series");
        System.out.println("2. Search Series");
        System.out.println("3. Update Series");
        System.out.println("4. Delete Series");
        System.out.println("5. Series Report");
        System.out.println("6. Exit Application");
        System.out.print("Enter your choice: ");
    }

    // Capture a new series
    public void captureSeries() {
        System.out.print("Enter Series ID: ");
        String id = input.nextLine();
        System.out.print("Enter Series Name: ");
        String name = input.nextLine();

        // Get a valid age restriction from the user
        int num = 0;
        boolean validAge = false;
        while (!validAge) {
            System.out.print("Enter age restriction (2-18): ");
            if (input.hasNextInt()) {
                num = input.nextInt();
                if (num >= 2 && num <= 18) {
                    validAge = true; // Exit loop if age is valid
                } else {
                    System.out.println("Invalid age. Enter 2-18.");
                }
            } else {
                System.out.println("Numbers only please.");
                input.next();
            }
        }
        input.nextLine();
        String age = String.valueOf(num); // Convert integer to String

        // Get number of episodes
        System.out.print("Enter number of episodes: ");
        String episodes = input.nextLine();

        // Add the new series to the list
        seriesList.add(new SeriesData(id, name, age, episodes));
        System.out.println("Series successfully captured!");
    }

    // Search for a series by ID
    public void searchSeries() {
        System.out.print("Enter Series ID to search: ");
        String searchId = input.nextLine();
        boolean found = false;
        for (SeriesData s : seriesList) {
            if (s.id.equals(searchId)) {
                System.out.println("Series found:");
                s.printInfo();  
                found = true;
                break;
            }
        }
        if (!found) System.out.println("Series not found.");
    }

    // Update an existing series
    public void updateExistingSeries() {
        System.out.print("Enter Series ID to update: ");
        String updateId = input.nextLine();
        boolean updated = false;

        for (SeriesData s : seriesList) {
            if (s.id.equals(updateId)) {
                System.out.print("Enter new Series Name (leave blank to keep current): ");
                String newName = input.nextLine();
                if (!newName.isEmpty()) s.name = newName;

                // Update age with validation
                boolean validNewAge = false;
                while (!validNewAge) {
                    System.out.print("Enter new Age Restriction (2-18, leave blank to keep current): ");
                    String ageInput = input.nextLine();
                    if (ageInput.isEmpty()) {
                        validNewAge = true; // Keep current
                    } else {
                        try {
                            int num = Integer.parseInt(ageInput);
                            if (num >= 2 && num <= 18) {
                                s.ageRestriction = ageInput;
                                validNewAge = true;
                            } else {
                                System.out.println("Invalid age. Enter 2-18.");
                            }
                        } catch(NumberFormatException e) {
                            System.out.println("Numbers only please.");
                        }
                    }
                }

                System.out.print("Enter new Number of Episodes (leave blank space to keep current): ");
                String newEpisodes = input.nextLine();
                if (!newEpisodes.isEmpty()) s.numberOfEpisodes = newEpisodes;

                System.out.println("Series updated successfully!");
                updated = true;
                break;
            }
        }

        if (!updated) System.out.println("Series not found.");
    }

    // Delete a series
    public void deleteSeries() {
        System.out.print("Enter Series ID to delete: ");
        String deleteId = input.nextLine();
        SeriesData toDelete = null;

        for (SeriesData s : seriesList) {
            if (s.id.equals(deleteId)) { 
                toDelete = s; 
                break; 
            }
        }

        if (toDelete != null) {
            System.out.print("Are you sure you want to delete this series? (Yes/No): ");
            String toconfirm = input.nextLine();
            if (toconfirm.equalsIgnoreCase("Yes")) {
                seriesList.remove(toDelete);
                System.out.println("Series is successfully deleted!");
            } else {
                System.out.println("Deleting process has been cancelled.");
            }
        } else {
            System.out.println("Series is not recognised.");
        }
    }

    // Print report of all series
    public void PrintTheSeries() {
        if (seriesList.isEmpty()) System.out.println("No serieses are available.");
        else for (SeriesData s : seriesList) s.printInfo();
    }

    // close the application when you are done using the application
    public void CloseApplication() {
        System.out.println("Exiting application...");
    }

    // helper methods

    // Search series by ID
    public SeriesData searchSeriesById(String id) {
        for (SeriesData s : seriesList) {
            if (s.id.equals(id)) return s;
        }
        return null; // Not found
    }

    // Update series by ID
    public boolean updateSeriesById(String id, String name, String age, String episodes) {
        for (SeriesData s : seriesList) {
            if (s.id.equals(id)) {
                if (name != null && !name.isEmpty()) s.name = name;
                if (age != null && !age.isEmpty()) s.ageRestriction = age;
                if (episodes != null && !episodes.isEmpty()) s.numberOfEpisodes = episodes;
                return true;
            }
        }
        return false; // Series not found
    }

    // Delete series by ID
    public boolean deleteSeriesById(String id) {
        for (SeriesData s : seriesList) {
            if (s.id.equals(id)) {
                seriesList.remove(s);
                return true;
            }
        }
        return false; // Series not found
    }

    // Validate age restriction
    public boolean isAgeValid(String age) {
        try {
            int num = Integer.parseInt(age);
            return num >= 2 && num <= 18;
        } catch(NumberFormatException e) {
            return false;
        }
    }
}
