 package com.mycompany.tvstreaming.tests;

import com.mycompany.tvstreaming.Series;

public class SeriesTest {

    public static void main(String[] args) {
        ExecuteTests(); // Run all the tests
    }

    public static void ExecuteTests() {
        Series app = new Series();

        //series test is added for testing purposes
        app.seriesList.add(new Series.SeriesData("001", "Test Series", "12", "10"));
//prints the outcome
        System.out.println("Running simulated unit tests...");

        // Test 1, ensures series with that particular id exists on the list
        assert app.searchSeriesById("001") != null : "Test Failed: Search series found";

        // Test 2: Search series and diplay a message if it is  not found
        assert app.searchSeriesById("999") == null : "Test Failed: Search series not found";

        // Test 3: checks for Updated series
        boolean updated = app.updateSeriesById("001", "Updated Series", "14", "12");
        assert updated : "Test Failed: Update series";
        assert app.searchSeriesById("001").name.equals("Updated Series") : "Test Failed: Name not updated";
        assert app.searchSeriesById("001").ageRestriction.equals("14") : "Test Failed: Age not updated";
        assert app.searchSeriesById("001").numberOfEpisodes.equals("12") : "Test Failed: Episodes not updated";

        // Test 4: tet for removed series
        boolean deleted = app.deleteSeriesById("001");
        assert deleted : "Test Failed: Delete series";
        assert app.searchSeriesById("001") == null : "Test Failed: Series still exists after deletion";

        // Test 5: Delete series that is not found
        boolean deleteNonExistent = app.deleteSeriesById("999");
        assert !deleteNonExistent : "Test Failed: Deleting non-existent series should fail";

        // Test 6: Valid age restriction
        assert app.isAgeValid("12") : "Test Failed: Age should be valid";

        // Test 7: Invalid age restriction
        assert !app.isAgeValid("25") : "Test Failed: Age should be invalid";

        System.out.println("All simulated tests passed!");
    }
}
