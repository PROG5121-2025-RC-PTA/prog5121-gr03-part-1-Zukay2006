package com.mycompany.clinicbookingsystem;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author zukha
 */
public class ClinicBookingSystem {
    //list to keep a record of all patients and its private because you want to control access to the patients lists 
    private static ArrayList<Patient> patients = new ArrayList<>();
    private static int ticketCounter = 1; // it is used to generate ticket numbers

    public static void main(String[] args) {
        //scanner is introduced after importing it
        Scanner sc = new Scanner(System.in);
        System.out.println("Welcome to Public Clinic Booking System ");

        while (true) {
            // list of the menu option
            System.out.println("\n1. Book Appointment");
            System.out.println("2. Enquiries");
            System.out.println("3. View All Bookings (Report)");
            System.out.println("4. Exit");
            System.out.print("Choose option: ");
            int choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {// help of Ai was used
                case 1 -> bookAppointment(sc);
                case 2 -> EnquiriesSection(sc);
                case 3 -> printReport();
                case 4 -> {
                    System.out.println("You are about to exist the system... Goodbye and have a great day!");
                    return;
                }
                default -> System.out.println("Invalid option, try again.");
            }
        }
    }

    
    private static void EnquiriesSection(Scanner sc) {
        System.out.println("\nSelect the clinic you wish to contact below:");
        System.out.println("1. Clinic A (Phone: 0123456789)");
        System.out.println("2. Clinic B (Phone: 07654321)");
        System.out.println("3. Other enquiries (0782115678)");
        System.out.print("Choose option: ");
        int option = sc.nextInt();
        sc.nextLine();

        switch(option) {
            case 1 -> System.out.println("Clinic A number: 0123456789");
            case 2 -> System.out.println("Clinic B number: 0987654321");
            case 3 -> System.out.println("For other enquiries call: 0782115678");
            default -> System.out.println("Invalid option.");
        }
    }

    
    private static void bookAppointment(Scanner sc) {
        System.out.print("Do you have an existing file at the clinic you wish to book an appointment at? (yes/no): ");
        //Ai was used for assistance
        String fileAnswer = sc.nextLine().trim().toLowerCase();
        //boolean is used for choosing between 2 options such as yes or no, true or false
        boolean hasFile = fileAnswer.equals("yes");
// declaring your variables
        String name = "";
        String surname = "";
        String phone = "";
        String fileNumber = "";

        if (!hasFile) {
            System.out.print("Enter file number: ");
            fileNumber = sc.nextLine();
            System.out.print("Enter Name: ");
            name = sc.nextLine();
            System.out.print("Enter Surname: ");
            surname = sc.nextLine();
            System.out.print("Enter Phone Number: ");
            phone = sc.nextLine();
        } else {
            // placeholder details for existing file
            name = "Unknown";
            surname = "Unknown";
            phone = "N/A";
        }

        System.out.print("Enter your location: ");
        String userLocation = sc.nextLine();

        System.out.print("Select Province: ");
        String province = sc.nextLine();

        System.out.println("Select reason for visit:");
        System.out.println("1. Vaccination");
        System.out.println("2. Family Planning");
        System.out.println("3. Consultation");
        System.out.println("4. Other reasons");
        System.out.print("Enter option: ");
        int reasonOption = sc.nextInt();
        sc.nextLine(); 

        String reason; // Ai was used for assiastance in this section 
        switch(reasonOption) {
            case 1 -> reason = "Vaccination";
            case 2 -> reason = "Family Planning";
            case 3 -> reason = "Consultation";
            case 4 -> {
                System.out.print("Please specify other reasons: ");
                reason = sc.nextLine();
            }
            default -> reason = "Other reasons";
        }

        System.out.print("Enter the clinic name you wish to book: ");
        String clinicName = sc.nextLine();// prints or display the users answer

        
        System.out.println("️Please make sure the clinic you choose is < or = 5 km from your location.");
        System.out.println("If you choose a clinic that is more than 5km you may not be accepted or assisted in that particular clinic.");

       
        int hour;
        while (true) {
            System.out.print("Enter booking hour: ");
            hour = sc.nextInt();
            sc.nextLine(); 
// check if the current time is between 11 and 12
            if (hour >= 11 && hour < 12) {
                System.out.println("Oops! Nurses/doctors are not available at that time, please choose another time.");
            } else if (hour >= 15) {
                System.out.println("Oops! Clinic is closed after 3 PM, please choose another time or another day.");
            } else {
                break; 
            }
        }

        
        String section = "";
        String expectedStaff = "";
        switch(reason.toLowerCase()) {
            case "vaccination" -> {
                // directs patience to the correct location on the day of the appointment
                section = "Vaccination Room, Number 626, first door, on your right";
                expectedStaff = "Nurse Vilakazi";
            }
            case "family planning" -> {
                section = "Family Planning Room, Number 129, first double door, on your left";
                expectedStaff = "Nurse Manyaka";
            }
            case "consultation" -> {
                section = "Consultation Room, Number 789, straight ahead, second left";
                expectedStaff = "Doctor Ashwin";
            }
            default -> {
                section = "General Room, Number 321, first floor, reception left";
                expectedStaff = "Nurse/Doctor";
            }
        }

        
        Patient p = new Patient(name, surname, phone, hasFile, reason, hour,
                province, clinicName, ticketCounter++, section, expectedStaff);
        patients.add(p);

        //confirmation message
        System.out.println("Appointment Confirmed!");
        System.out.println("Ticket Number: #" + p.getTicketNumber());
        System.out.println("Section: " + p.getSection());
        System.out.println("Expected Staff: " + p.getExpectedStaff());
        System.out.println("Please expect an SMS or phone call to confirm and remind you of your booking.");
    }

    
    private static void OutputReport() {
        System.out.println("Clinic Booking Report");
        if (patients.isEmpty()) {
            System.out.println("No appointments booked yet.");
            return;
        }
//Ai was used for this section 
        for (Patient p : patients) {
            System.out.println("Ticket #" + p.getTicketNumber());
            System.out.println("Name: " + p.getName() + " " + p.getSurname());
            System.out.println("Phone: " + p.getPhone());
            System.out.println("Has File: " + (p.hasFile() ? "Yes" : "No"));
            System.out.println("Province: " + p.getProvince());
            System.out.println("Clinic: " + p.getClinicName());
            System.out.println("Reason: " + p.getReason());
            System.out.println("Booking Hour: " + p.getBookingHour() + ":00");
            System.out.println("Section: " + p.getSection());
            System.out.println("Expected Staff: " + p.getExpectedStaff());
            System.out.println("---------------------------");
        }
    }
}


class Person { // classs was created to store the partcular individuals information
    private String name;
    private String surname;
    private String phone;

    public Person(String name, String surname, String phone) {
        this.name = name;
        this.surname = surname;
        this.phone = phone;
    }
// returns the name, surname and phone number of that particular individual
    public String getName() { return name; }
    public String getSurname() { return surname; }
    public String getPhone() { return phone; }
}

// represents a person with extra or additional information
class Patient extends Person {
    private boolean hasFile;
    private String reason;
    private int bookingHour;
    private String province;
    private String clinicName;
    private int ticketNumber;
    private String section;
    private String expectedStaff;

    public Patient(String name, String surname, String phone, boolean hasFile,
                   String reason, int bookingHour, String province, String clinicName,
                   int ticketNumber, String section, String expectedStaff) {
        super(name, surname, phone);
        this.hasFile = hasFile;
        this.reason = reason;
        this.bookingHour = bookingHour;
        this.province = province;
        this.clinicName = clinicName;
        this.ticketNumber = ticketNumber;
        this.section = section;
        this.expectedStaff = expectedStaff;
    }
//this section it is Ai generated
    public boolean hasFile() { return hasFile; }
    public String getReason() { return reason; }
    public int getBookingHour() { return bookingHour; }
    public String getProvince() { return province; }
    public String getClinicName() { return clinicName; }
    public int getTicketNumber() { return ticketNumber; }
    public String getSection() { return section; }
    public String getExpectedStaff() { return expectedStaff; }
}
